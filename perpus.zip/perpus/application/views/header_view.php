<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $title_web;?> | Sistem Informasi Perpustakaan Codekop </title>
  <!-- Tell the browser to be responsive to screen width -->


  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/bower_components/font-awesome/css/font-awesome.min.css">
	
	
	<!-- Select2 -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/bower_components/select2/dist/css/select2.min.css">
	
	<!-- Ionicons -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/bower_components/Ionicons/css/ionicons.min.css">
	<!-- Theme style -->  
	
	<link href="<?php echo base_url();?>assets_style/assets/plugins/summernote/summernote-lite.css" rel="stylesheet">

  <link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/dist/css/AdminLTE.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/dist/css/responsive.css">
	
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/plugins/timepicker/bootstrap-timepicker.min.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/dist/css/skins/_all-skins.min.css">

  <link rel="stylesheet" href="<?php echo base_url();?>assets_style/assets/plugins/pace/pace.min.css">
  <!-- jQuery 3 -->
  <script src="<?php echo base_url();?>assets_style/assets/bower_components/jquery/dist/jquery.min.js"></script>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	<!-- offline -->
  <script type="text/javascript">
      $(document).ajaxStart(function() { Pace.restart(); });
  </script>
</head>
<body class="hold-transition skin-blue-light sidebar-mini" style="background-color: aquamarine; font-family: italic;">
<div class="wrapper">
  <header class="main-header" >

    <!-- Logo -->
    <a href="<?php echo base_url('index.php/dashboard');?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>P</b>C</span>
      <!-- logo for regular state and mobile devices -->
      <!--<span class="logo-lg" style="font-family: italic;">Perpus Han's</span>-->
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background-color: #34B3F1; ">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <b><span class="logo-lg" style="font-family: italic; color:rgb(11, 11, 11);" alight="center">Perpus Han's</span>
  </b></a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu" style="background-color: #34B3F1; color:rgb(11, 11, 11);">
        <ul class="nav navbar-nav">
          <li>
            <?php
              $d = $this->db->query("SELECT * FROM tbl_login WHERE id_login = '$idbo'")->row();
             ?>
            <!--<a href="<?= base_url('user/edit/'.$idbo);?>">
              Welcome , <i class="fa fa-edit"> </i> <?php echo $d->nama; echo ' | ( '.$d->level.' )'; ?></a>-->
          </li>
          <li style="margin-top: 15px; margin-right: 10px;">
            <b><a href="<?php echo base_url();?>login/logout" style="color:rgb(11, 11, 11); ">Sign out</a></b>
          </li>
          <!-- Control Sidebar Toggle Button 
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>-->
        </ul>
      </div>
    </nav>
    <aside class="main-sidebar" style="background-color: #34B3F1; font-family: italic;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel" style="color:aliceblue;">
        <div class="pull-left image">
          <?php
            $d = $this->db->query("SELECT * FROM tbl_login WHERE id_login='$idbo'")->row();
            if(!empty($d->foto !== "-")){
          ?>
          <br/>
          <img src="<?php echo base_url();?>assets_style/image/<?php echo $d->foto;?>" alt="#" c
          lass="user-image" style="border:4px solid #fff;height:auto;width:100%;"/>
          <?php }else{?>
            <!--<img src="" alt="#" class="user-image" style="border:2px solid #fff;"/>-->
            <i class="fa fa-user fa-4x" style="color:#fff;"></i>
          <?php }?>
        </div>
        <div class="pull-left info" style="margin-top: 5px;" style="margin-left: 30px;">
          <p><?php echo $d->nama;?></p>
          <p><?= $d->level;?>
          </p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
        <br/>
        <br/>
        <br/>
        <br/>
        <ul class="sidebar-menu" data-widget="tree">
			<?php if($this->session->userdata('level') == 'Petugas'){?>
      <!-- sidebar menu: : style can be found in sidebar.less -->
        <li class="header"></li>
        <li class="<?php if($this->uri->uri_string() == 'dashboard'){ echo 'active';}?>">
          <a href="<?php echo base_url('dashboard');?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="<?php if($this->uri->uri_string() == 'user'){ echo 'active';}?>
        <?php if($this->uri->uri_string() == 'user/tambah'){ echo 'active';}?>
        <?php if($this->uri->uri_string() == 'user/edit/'.$this->uri->segment('3')){ echo 'active';}?>">
          <a href="<?php echo base_url('user');?>" class="cursor">
            <i class="fa fa-user"></i> <span>Data Pengguna</span></a>
				</li>
				<li class="treeview <?php if($this->uri->uri_string() == 'data/kategori'){ echo 'active';}?>
				<?php if($this->uri->uri_string() == 'data/rak'){ echo 'active';}?>
				<?php if($this->uri->uri_string() == 'data'){ echo 'active';}?>
				<?php if($this->uri->uri_string() == 'data/bukutambah'){ echo 'active';}?>
				<?php if($this->uri->uri_string() == 'data/bukudetail/'.$this->uri->segment('3')){ echo 'active';}?>
				<?php if($this->uri->uri_string() == 'data/bukuedit/'.$this->uri->segment('3')){ echo 'active';}?>">
          <a href="#">
            <i class="fa fa-pencil-square"></i>
            <span>Data </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" >
						<li class="<?php if($this->uri->uri_string() == 'data'){ echo 'active';}?>
						<?php if($this->uri->uri_string() == 'data/bukutambah'){ echo 'active';}?>
						<?php if($this->uri->uri_string() == 'data/bukudetail/'.$this->uri->segment('3')){ echo 'active';}?>
						<?php if($this->uri->uri_string() == 'data/bukuedit/'.$this->uri->segment('3')){ echo 'active';}?>">
							<a href="<?php echo base_url("data");?>" class="cursor">
								<span class="fa fa-book"></span> Data Buku
								
							</a>
						</li>
						<li class=" <?php if($this->uri->uri_string() == 'data/kategori'){ echo 'active';}?>">
							<a href="<?php echo base_url("data/kategori");?>" class="cursor">
								<span class="fa fa-tags"></span> Kategori
								
							</a>
						</li>
						<li class=" <?php if($this->uri->uri_string() == 'data/rak'){ echo 'active';}?>">
							<a href="<?php echo base_url("data/rak");?>" class="cursor">
								<span class="fa fa-list"></span> Rak
								
							</a>
						</li>
          </ul>
        </li>
				<li class="treeview 
					<?php if($this->uri->uri_string() == 'transaksi'){ echo 'active';}?>
					<?php if($this->uri->uri_string() == 'transaksi/pinjam'){ echo 'active';}?>
					<?php if($this->uri->uri_string() == 'transaksi/detailpinjam/'.$this->uri->segment('3')){ echo 'active';}?>
					<?php if($this->uri->uri_string() == 'transaksi/kembalipinjam/'.$this->uri->segment('3')){ echo 'active';}?>">
          <a href="#">
            <i class="fa fa-download"></i>
            <span>Transaksi</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
					<ul class="treeview-menu">
						<li class="<?php if($this->uri->uri_string() == 'transaksi'){ echo 'active';}?>
							<?php if($this->uri->uri_string() == 'transaksi/pinjam'){ echo 'active';}?>
							<?php if($this->uri->uri_string() == 'transaksi/detailpinjam/'.$this->uri->segment('3')){ echo 'active';}?>
							<?php if($this->uri->uri_string() == 'transaksi/kembalipinjam/'.$this->uri->segment('3')){ echo 'active';}?>">
							<a href="<?php echo base_url("transaksi");?>" class="cursor">
								<span class="fa fa-upload"></span> Peminjaman
								
							</a>
						</li>
				<!--
						<li class="">
							<a href="<?php echo base_url("buku");?>" class="cursor">
								<span class="fa fa-list"></span> laporan
								
							</a>
						</li>-->
          </ul>
        </li>
				<li class="<?php if($this->uri->uri_string() == 'transaksi/denda'){ echo 'active';}?>">
					<a href="<?php echo base_url("transaksi/denda");?>" class="cursor">
						<i class="fa fa-money"></i> <span>Denda</span>
						
					</a>
				</li>
			<?php }?>
			<?php if($this->session->userdata('level') == 'Anggota'){?>
				<li class="<?php if($this->uri->uri_string() == 'transaksi'){ echo 'active';}?>">
					<a href="<?php echo base_url("transaksi");?>" class="cursor">
						<i class="fa fa-upload"></i> <span>Data Peminjaman Anggota</span>
					</a>
				</li>
				<li class="<?php if($this->uri->uri_string() == 'data'){ echo 'active';}?>
				<?php if($this->uri->uri_string() == 'data/bukudetail/'.$this->uri->segment('3')){ echo 'active';}?>">
					<a href="<?php echo base_url("data");?>" class="cursor">
						<i class="fa fa-search"></i>  <span>Cari Buku</span>
					</a>
				</li>
				<li class="<?php if($this->uri->uri_string() == 'user/edit/'.$this->uri->segment('3')){ echo 'active';}?>">
					<a href="<?php echo base_url('user/edit/'.$this->session->userdata('ses_id'));?>" class="cursor">
						<i class="fa fa-user"></i>  <span>Data Anggota</span>
					</a>
				</li>
				<!--<li class="">
					<a href="<?php echo base_url('user/detail/'.$this->session->userdata('ses_id'));?>" target="_blank" class="cursor">
						<i class="fa fa-print"></i> <span>Cetak kartu Anggota</span>
					</a>
				</li>-->
			<?php }?>
        <!--
        <li class="treeview">
            <a href="#">
              <i class="fa fa-pencil-square"></i>
              <span>Menu</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">

            </ul>
        </li>-->
        
      </ul>

			</div>
              <div class="clearfix"></div>
        <br/>
        <br/>
    </section>
    <!-- /.sidebar -->
  </aside>
  </header>
  <!--loading-->
  <!-- Left side column. contains the logo and sidebar -->
